# Datasets for Freeform dplyr lab

fivethirtyeight_cdc_full_data.csv - from https://github.com/fivethirtyeight/guns-data and accompanying Gun Deaths in America project https://fivethirtyeight.com/features/gun-deaths/  
  
Stanford_MSA_Database_for_release_06142016.xlsx - Stanford Libraries Mass Shootings in America database https://library.stanford.edu/projects/mass-shootings-america  
  
Natality, 2007-2015.txt - CDC Natality Data, see https://wonder.cdc.gov/wonder/help/Natality.html#  
  
Underlying Cause of Death, 1999-2016.txt - from the CDC see https://wonder.cdc.gov/wonder/help/ucd.html# for documentation  


